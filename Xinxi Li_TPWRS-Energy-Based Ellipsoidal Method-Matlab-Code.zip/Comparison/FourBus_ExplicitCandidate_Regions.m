%% Four-bus DC microgrid: certified regions of four solvability conditions
clear; clc;
folder=fileparts(mfilename('fullpath')); if isempty(folder), folder=pwd; end

%% System
uref=1; K=diag([.5,1]);
g1=4; g12=1; g2=2;
Y=[g1 0 -g1 0; 0 g2 0 -g2; -g1 0 g1+g12 -g12; 0 -g2 -g12 g2+g12];
YSS=Y(1:2,1:2); YSL=Y(1:2,3:4); YLL=Y(3:4,3:4);
delta=K\ones(2,1); theta=(YSS\YSL).'*delta; b=delta.'*(YSS\delta);
Y1=YLL-YSL.'*(YSS\YSL)+theta*theta.'/b; Y1=(Y1+Y1.')/2;

%% Radial search for the certified boundaries
angles=linspace(0,pi/2,2001).'; directions=[cos(angles),sin(angles)];
limits=radialLimits(Y1,uref,directions);
areas=0.5*trapz(angles,limits.^2,1);

%% Numerical positive-PFS envelope
rhs=uref*sum(Y1,2);
p1Cap=rhs(1)^2/(4*Y1(1,1)); p2Cap=rhs(2)^2/(4*Y1(2,2));
p1NR=linspace(1e-8,p1Cap-1e-8,600);
p2NR=arrayfun(@(p) positiveEnvelope(p,Y1,uref),p1NR);

%% Figure
fig=figure('Color','w','Position',[100 100 1000 680],'Renderer','painters');
ax=axes('Parent',fig,'Position',[.11 .12 .85 .84]); hold(ax,'on');

names={'Condition (36)','Condition (9)','Condition (11)','Condition (13)'};
style={'--',':','-.','-'};

clrRank=[0.85 0.12 0.10; 0.10 0.55 0.15; 0.75 0.08 0.65; 0.05 0.30 0.75];
[~,ordAsc]=sort(areas,'ascend');
colorOf=zeros(4,3);
for r=1:4, colorOf(ordAsc(r),:)=clrRank(r,:); end
ordDesc=flipud(ordAsc);

hh=gobjects(1,5);
hh(1)=plot(ax,[0 p1NR p1Cap],[p2Cap p2NR 0],'k-','LineWidth',2);

for r=1:4
    j=ordDesc(r);
    xy=limits(:,j).*directions;
    switch style{j}
        case ':',  lwj=3.8;
        case '-.', lwj=2.8;
        case '--', lwj=2.4;
        otherwise, lwj=2.2;
    end
    hh(j+1)=plot(ax,xy(:,1),xy(:,2),style{j},'Color',colorOf(j,:),'LineWidth',lwj);
end

xlabel(ax,'$p_1$ (p.u.)','Interpreter','latex');
ylabel(ax,'$p_2$ (p.u.)','Interpreter','latex');
xlim(ax,[0 1.05*p1Cap]); ylim(ax,[0 1.05*p2Cap]);
set(ax,'FontName','Times New Roman','FontSize',14,'LineWidth',2);
box(ax,'on'); grid(ax,'off');
legend(ax,hh,['Positive-PFS envelope (numerical)' names], ...
    'Location','northeast','FontSize',11);
drawnow;

%% Export
exportgraphics(fig,fullfile(folder,'FourBus_regions.png'),'Resolution',300);
print(fig,fullfile(folder,'FourBus_regions.emf'),'-dmeta','-painters');
print(fig,fullfile(folder,'FourBus_regions.svg'),'-dsvg','-painters');

fprintf('Areas: %.4f %.4f %.4f %.4f\n',areas);

%% ===================== functions =====================
function lim=radialLimits(Y,U,dirs)
lo=zeros(size(dirs,1),4);
hi=50*max(diag(Y))*U^2*ones(size(lo));
for k=1:40
    mid=(lo+hi)/2;
    for j=1:4
        Q=scores(mid(:,j).*dirs,Y,U);
        pass=Q(:,j)<1;
        lo(:,j)=pass.*mid(:,j)+(~pass).*lo(:,j);
        hi(:,j)=pass.*hi(:,j)+(~pass).*mid(:,j);
    end
end
lim=lo;
end

function Q=scores(P,Y,U)
B=Y\eye(2); P=P/U^2;
t11=B(1,1)*P(:,1); t12=B(1,2)*P(:,2);
t21=B(2,1)*P(:,1); t22=B(2,2)*P(:,2);
eta=[t11+t12, t21+t22];
zeta=[abs(t11)+abs(t12), abs(t21)+abs(t22)];

Q=zeros(size(P,1),4);
Q(:,1)=eemScore(P*U^2,Y,U);

sig=[max(t11,0)+max(t12,0), max(t21,0)+max(t22,0)];
omg=[max(-t11,0)+max(-t12,0), max(-t21,0)+max(-t22,0)];
chi=max(max(omg,[],2)+min(sig,[],2), min(omg,[],2)+max(sig,[],2));
chi1=max(max(sig,[],2)-min(omg,[],2), max(omg,[],2)-min(sig,[],2));
Q(:,2)=chi+3*(max(chi1,0)/2).^(2/3);

psi=max(2*(zeta+eta)-zeta.^2-eta.^2,[],2);
nu=max(zeta,[],2);
rho=zeta.*sqrt(max(0,(1-psi)/2))./nu;
c=1-eta; D=c.^2-rho.^2;
valid=psi<1 & all(rho>0 & rho<c,2);
h17=(D-c)./D; rr=rho./D;
lhs=[abs(t11.*h17(:,1)+t12.*h17(:,2))+abs(t11).*rr(:,1)+abs(t12).*rr(:,2), ...
     abs(t21.*h17(:,1)+t22.*h17(:,2))+abs(t21).*rr(:,1)+abs(t22).*rr(:,2)];
Q(:,3)=max(lhs./rho,[],2); Q(~valid,3)=Inf;

Q(:,4)=2*double(~all(inRegion(sig,omg),2));
Q(~isfinite(Q))=Inf;
end

function [Q,v,H,beta,h,kappa]=eemScore(P,Y,U)
B=Y\eye(2); eta=P*B.'/U^2;
disc=1-4*eta; z=(1+sqrt(max(0,disc)))/2;
v=U*(1-(P./z)*B.'/U^2);
valid=all(disc>=0,2);
d=P./v.^2;
a=Y(1,1)-d(:,1); b=Y(2,2)-d(:,2); c=Y(1,2);
detH=a.*b-c*c;
pd=valid & all(v>0,2) & a>0 & detH>0;
den=detH; den(~pd)=NaN;
g=(v-U)*Y.'+P./v;
beta=sqrt(max(0,(b.*g(:,1).^2-2*c*g(:,1).*g(:,2)+a.*g(:,2).^2)./den));
h=max(sqrt(b./den)./v(:,1), sqrt(a./den)./v(:,2));
kappa=max(b.*d(:,1)+abs(c)*d(:,2), abs(c)*d(:,1)+a.*d(:,2))./den;
delta=h.*beta; Q=delta+2*sqrt(kappa.*delta);
Q(~pd | ~isfinite(Q))=Inf;
H=[]; if size(P,1)==1, H=[a c; c b]; end
end

function ok=inRegion(x,y)
ok=false(size(x));
m=x<=1/4;                 ok(m)=y(m)>=0 & y(m)<=.5*x(m)+1;
m=x>1/4 & x<=(3-sqrt(5))/2; ok(m)=y(m)>=2*sqrt(x(m))-1 & y(m)<=.5*x(m)+1;
m=x>(3-sqrt(5))/2 & x<=2/3; ok(m)=y(m)>=x(m).^2./(1-x(m)) & y(m)<=.5*x(m)+1;
end

function p2=positiveEnvelope(p1,Y,ref)
a=Y(1,1); b=Y(2,2); c=Y(1,2); rhs=ref*sum(Y,2);
N=[-a rhs(1) -p1]; R=[b*a-c*c c*rhs(2)-b*rhs(1) b*p1];
M=conv(N,R);
derivative=[polyder(M) 0]-2*M;
xs=roots(derivative); p2=0;
for j=1:numel(xs)
    if abs(imag(xs(j)))<1e-7 && real(xs(j))>0
        x=real(xs(j)); y=polyval(N,x)/(c*x);
        if y>0, p2=max(p2,y*(rhs(2)-c*x-b*y)); end
    end
end
end