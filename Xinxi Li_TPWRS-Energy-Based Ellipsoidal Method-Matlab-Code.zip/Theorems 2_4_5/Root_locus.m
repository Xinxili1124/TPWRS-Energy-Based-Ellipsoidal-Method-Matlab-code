%% ===================== IEEE 123 =====================
N = 123;
Y = zeros(N);
Y(1,36)=0.1;    Y(2,33)=1;      Y(3,39)=5;      Y(4,45)=0.2;    Y(5,47)=2;
Y(6,48)=0.5;    Y(7,50)=5;      Y(8,57)=1;      Y(9,58)=0.2;    Y(10,55)=4;
Y(11,73)=0.5;   Y(12,68)=4;     Y(13,69)=0.5;   Y(14,78)=4;     Y(15,79)=0.5;
Y(16,79)=10;    Y(17,82)=2;     Y(18,84)=1;     Y(19,103)=0.25; Y(20,91)=1;
Y(21,93)=2;     Y(22,112)=0.25; Y(23,113)=0.2;  Y(24,117)=5;    Y(25,118)=10;
Y(26,108)=0.2;  Y(27,122)=4;    Y(28,109)=0.5;  Y(29,112)=10;   Y(30,123)=5;
Y(31,34)=0.5;   Y(32,33)=4;     Y(32,35)=0.5;   Y(34,37)=10;    Y(35,38)=0.2;
Y(36,37)=2;     Y(37,38)=1;     Y(38,48)=0.25;  Y(39,40)=0.5;   Y(39,49)=0.2;
Y(40,41)=1;     Y(41,42)=0.2;   Y(42,43)=0.1;   Y(43,44)=4;     Y(44,51)=1;
Y(45,46)=4;     Y(45,52)=0.25;  Y(46,47)=1;     Y(48,57)=4;     Y(49,50)=2;
Y(49,53)=1;     Y(51,60)=2;     Y(51,52)=5;     Y(53,54)=4;     Y(53,58)=0.25;
Y(55,56)=0.5;   Y(56,59)=1;     Y(57,65)=10;    Y(58,67)=1;     Y(59,70)=0.1;
Y(60,61)=0.2;   Y(60,71)=0.5;   Y(61,62)=10;    Y(63,64)=2;     Y(64,65)=0.5;
Y(65,66)=0.2;   Y(65,94)=0.1;   Y(66,67)=5;     Y(67,68)=0.1;   Y(68,69)=1;
Y(70,84)=4;     Y(71,72)=1;     Y(71,74)=1;     Y(72,73)=10;    Y(74,75)=2;
Y(75,76)=0.5;   Y(75,86)=5;     Y(76,77)=5;     Y(77,78)=10;    Y(79,81)=4;
Y(80,91)=5;     Y(81,93)=0.25;  Y(82,83)=0.25;  Y(83,84)=0.2;   Y(83,98)=0.5;
Y(84,85)=2;     Y(85,86)=0.1;   Y(86,87)=0.5;   Y(86,101)=0.25; Y(87,88)=0.2;
Y(88,89)=1;     Y(89,90)=2;     Y(91,92)=10;    Y(91,109)=0.1;  Y(92,93)=1;
Y(93,94)=0.5;   Y(94,95)=1;     Y(94,104)=0.2;  Y(95,96)=0.2;   Y(96,97)=5;
Y(97,98)=2;     Y(98,99)=0.5;   Y(98,105)=4;    Y(99,100)=1;    Y(101,102)=5;
Y(101,106)=2;   Y(102,103)=10;  Y(104,112)=0.5; Y(105,114)=0.1; Y(106,107)=1;
Y(106,119)=0.1; Y(107,108)=10;  Y(108,120)=0.5; Y(109,110)=0.5; Y(110,111)=4;
Y(113,114)=2;   Y(114,116)=1;   Y(115,116)=0.5; Y(116,117)=0.2; Y(117,118)=1;
Y(118,119)=0.2; Y(120,121)=1;   Y(121,122)=0.25; Y(121,123)=0.2;
Y = diag((Y+Y')*ones(N,1))-Y-Y';
YSS = Y(1:30,1:30);
YSL = Y(1:30,31:123);
YLL = Y(31:123,31:123);
K = diag([0.5*ones(15,1); ones(15,1)]);
uref = 2846;
p = 1000*[5*ones(31,1); 8*ones(31,1); 5*ones(31,1)];

delta = K\ones(30,1);
c = delta.'*(YSS\delta);
alpha = (delta.'*(YSS\YSL)).';
Y1 = YLL - YSL.'*(YSS\YSL) + (alpha*alpha.')/c;
Y1 = (Y1 + Y1.')/2;
xi = uref*sum(delta)*alpha/c;

%% ===================== closed-loop Jacobian =====================
gamma = 10;
h = size(YSS,1);
nL = size(YLL,1);
edgeWeight = 1;
adj = edgeWeight*circshift(eye(h),1,1);
L = diag(sum(adj+adj.',2)) - adj - adj.';
b1 = sum(delta);
Q = null(delta.');
TLT = K*L*K;
P = Q.'*TLT*Q; P = (P+P.')/2;
[Vp,dp] = eig(P,'vector');
assert(gamma > 0 && all(dp > 0));
P12 = Vp*diag(sqrt(dp))*Vp.';
S = Q.'*YSS*Q;
C = Q.'*YSL;
projectedCorrection = C.'*(S\C);

%% ===================== load grid =====================
basePower = 1000*[5*ones(31,1); 8*ones(31,1); 5*ones(31,1)];
u0 = -(Y1\xi);
initialDrop = Y1\(basePower./u0);

lambdaGrid = (0:0.002:2.12).';
lambdaExample = 2.0;
tol = 1e-8;
m = numel(lambdaGrid);

residual = nan(m,1);
minH = nan(m,1);
minG = nan(m,1);
minB = nan(m,1);
alphaJ = nan(m,1);
schurError = nan(m,1);
spectrumError = nan(m,1);
gammaError = nan(m,1);
eigStore = nan(h,m);

lastU = u0;

%% ===================== solve along the branch =====================
for k = 1:m
    lambda = lambdaGrid(k);
    pk = lambda*basePower;

    if k == 1
        uStart = u0;
    else
        uStart = lastU - 0.002*initialDrop;
    end

    [ok,u,Hmin] = solve_at(Y1,xi,pk,lambda,uStart,tol);
    if ~ok, continue; end
    lastU = u;

    residual(k) = norm(Y1*u+xi+pk./u,inf);
    Dstar = diag(pk./u.^2);
    Hstar = Y1 - Dstar;
    G = YLL - Dstar;
    minH(k) = min(eig(Hstar));
    minG(k) = min(eig(G));
    assert(residual(k)<tol && minH(k)>0 && minG(k)>0);

    Yomega = YSS - YSL*(G\YSL.');
    Yomega = (Yomega+Yomega.')/2;
    B = Q.'*Yomega*Q; B = (B+B.')/2;
    minB(k) = min(eig(B));
    schurError(k) = norm(G - projectedCorrection - Hstar,'fro')/norm(Hstar,'fro');

    J = -TLT*Yomega - (gamma/b1)*(ones(h,1)*delta.');
    direct = eig(J);
    eigStore(:,k) = direct;
    alphaJ(k) = max(real(direct));
    gammaError(k) = min(abs(direct+gamma));

    symmetricProduct = P12*B*P12;
    symmetricProduct = (symmetricProduct+symmetricProduct.')/2;
    predicted = -[eig(symmetricProduct); gamma];

    [~,order] = sort(real(direct));
    spectrumError(k) = max(abs(direct(order) - sort(predicted)));
end

certified = isfinite(minH);
assert(any(certified));
assert(all(minB(certified)>0) && all(alphaJ(certified)<0));
assert(max(spectrumError(certified)) < 1e-9);

%% ===================== refine the fold (annotation only) =====================
idxLast = find(certified,1,'last');
lamLo = lambdaGrid(idxLast);
uLo = lastU;
[~,uLo] = solve_at(Y1,xi,lamLo*basePower,lamLo,uLo,tol);

lamHi = min(lamLo + 0.30, 3.0);
for it = 1:60
    mid = (lamLo+lamHi)/2;
    [okm,um] = solve_at(Y1,xi,mid*basePower,mid,uLo,tol);
    if okm
        lamLo = mid; uLo = um;
    else
        lamHi = mid;
    end
end
lambdaFold = lamLo;

[~,exampleIndex] = min(abs(lambdaGrid-lambdaExample));

fprintf('gamma = %.1f, ring edge weight = %.1f, J dimension = %d\n',gamma,edgeWeight,h);
fprintf('Fold loading factor = %.6f\n',lambdaFold);
fprintf('lambda = %.3f: min eig H = %.9g, spectral abscissa = %.9g\n', ...
    lambdaGrid(exampleIndex),minH(exampleIndex),alphaJ(exampleIndex));
fprintf('Worst spectral abscissa = %.9g\n',max(alphaJ(certified)));
fprintf('Maximum relative Schur residual = %.3e; maximum spectrum mismatch = %.3e\n', ...
    max(schurError(certified)),max(spectrumError(certified)));
fprintf('Maximum numerical distance to the eigenvalue -gamma = %.3e\n', ...
    max(gammaError(certified)));

%% ===================== plot =====================
idxPlot = certified;
lambdaPlot = lambdaGrid(idxPlot);
minHPlot  = minH(idxPlot);
alphaPlot = alphaJ(idxPlot);

folder = fileparts(mfilename('fullpath'));

% ---- Figure 1: min eig H ----
fig1 = figure('Color','w','Position',[100 100 760 300]);
ax1 = axes('Parent',fig1,'Position',[0.11 0.20 0.86 0.70]);
plot(ax1,lambdaPlot,1e3*minHPlot,'Color',[0.08 0.35 0.60],'LineWidth',1.8);
hold(ax1,'on');
plot(ax1,lambdaPlot(exampleIndex),1e3*minHPlot(exampleIndex),'o', ...
    'Color',[0.08 0.35 0.60],'MarkerFaceColor',[0.08 0.35 0.60],'MarkerSize',5);
xline(ax1,lambdaFold,'--','Color',[0.45 0.45 0.45],'LineWidth',1.0);
text(ax1,lambdaFold-0.05,0.82*max(1e3*minHPlot), ...
    sprintf('$\\alpha_{fold}=%.3f$',lambdaFold), ...
    'Interpreter','latex','HorizontalAlignment','right','FontSize',14);
xlim(ax1,[0, lambdaFold*1.01]);
xt1 = unique([0 0.5 1 1.5 2 lambdaFold]);
xticks(ax1,xt1);
xticklabels(ax1,arrayfun(@(v) sprintf('%.2f',v),xt1,'UniformOutput',false));
ylim(ax1,[0, 1.08*max(1e3*minHPlot)]);
xlabel(ax1,'Loading factor $\lambda$','Interpreter','latex');
ylabel(ax1,'$\lambda_{\min}(H(u_L^*))$','Interpreter','latex');
title(ax1,'(a) The dominant eigenvalue of $H(u_L^*)$','Interpreter','latex','FontWeight','normal');
set(ax1,'FontName','Times New Roman','FontSize',12,'LineWidth',0.8);
text(ax1,0,1.02,'$\times 10^{-3}$','Units','normalized', ...
    'Interpreter','latex','FontSize',12,'VerticalAlignment','bottom');
box(ax1,'on');
try, ax1.Toolbar.Visible = 'off'; catch, end
exportgraphics(fig1,fullfile(folder,'theorem3_hessian.png'),'Resolution',300);

% ---- Figure 2: max Re eig J ----
fig2 = figure('Color','w','Position',[100 100 760 300]);
ax2 = axes('Parent',fig2,'Position',[0.11 0.20 0.86 0.70]);
plot(ax2,lambdaPlot,1e3*alphaPlot,'Color',[0.68 0.23 0.14],'LineWidth',1.8);
hold(ax2,'on');
plot(ax2,lambdaPlot(exampleIndex),1e3*alphaPlot(exampleIndex),'o', ...
    'Color',[0.68 0.23 0.14],'MarkerFaceColor',[0.68 0.23 0.14],'MarkerSize',5);
xline(ax2,lambdaFold,'--','Color',[0.45 0.45 0.45],'LineWidth',1.0);
text(ax2,lambdaFold-0.05,0.82*min(1e3*alphaPlot), ...
    sprintf('$\\alpha_{fold}=%.3f$',lambdaFold), ...
    'Interpreter','latex','HorizontalAlignment','right','FontSize',14);
xlim(ax2,[0, lambdaFold*1.01]);
xt2 = unique([0 0.5 1 1.5 2 lambdaFold]);
xticks(ax2,xt2);
xticklabels(ax2,arrayfun(@(v) sprintf('%.2f',v),xt2,'UniformOutput',false));
ylim(ax2,[1.10*min(1e3*alphaPlot), 0]);
xlabel(ax2,'Loading factor $\lambda$','Interpreter','latex');
ylabel(ax2,'$\max_i \mathrm{Re}\,\lambda_i(J)$','Interpreter','latex');
title(ax2,'(b) The dominant eigenvalue of $J$','Interpreter','latex','FontWeight','normal');
set(ax2,'FontName','Times New Roman','FontSize',12,'LineWidth',0.8);
text(ax2,0,1.02,'$\times 10^{-3}$','Units','normalized', ...
    'Interpreter','latex','FontSize',12,'VerticalAlignment','bottom');
box(ax2,'on');
try, ax2.Toolbar.Visible = 'off'; catch, end
exportgraphics(fig2,fullfile(folder,'theorem3_jacobian.png'),'Resolution',300);

% ---- Figure 3: root locus of J ----
fig3 = figure('Color','w','Position',[100 100 700 560]);
ax3 = axes('Parent',fig3);hold(ax3,'on');

cols = find(certified);
cmap = parula(numel(cols));
for q = 1:numel(cols)
    k = cols(q);
    plot(ax3,real(eigStore(:,k)),imag(eigStore(:,k)), ...
        '.','Color',cmap(q,:),'MarkerSize',7);
end

xline(ax3,0,'k--','LineWidth',1.0);
xlabel(ax3,'$\mathrm{Re}\,\lambda$','Interpreter','latex');
ylabel(ax3,'$\mathrm{Im}\,\lambda$','Interpreter','latex');
title(ax3,'Root locus of $J$ as $\lambda$ increases', ...
    'Interpreter','latex','FontWeight','normal');
cb = colorbar(ax3);
cb.Label.String = '$\lambda$';
cb.Label.Interpreter = 'latex';
set(ax3,'FontName','Times New Roman','FontSize',12,'LineWidth',0.8);
box(ax3,'on');
grid(ax3,'off');
try, ax3.Toolbar.Visible = 'off'; catch, end
exportgraphics(fig3,fullfile(folder,'theorem3_root_locus.png'),'Resolution',300);

%% ===================== local function =====================
%%%function [ok,u,Hmin] = solve_at(Y1,xi,p,lambda,uStart,tol)
    u = uStart;
    ok = false;
    Hmin = NaN;
    for it = 1:80
        g = Y1*u + xi + p./u;
        if norm(g,inf) < tol
            ok = true;
            break;
        end
        H = Y1 - diag(p./u.^2);
        [~,flag] = chol(H);
        if flag ~= 0
            return;
        end
        du = -(H\g);
        t = 1; acc = false;
        for ls = 1:60
            ut = u + t*du;
            if all(ut>0)
                Ht = Y1 - diag(p./ut.^2);
                [~,fl] = chol(Ht);
                if fl == 0 && norm(Y1*ut+xi+p./ut,inf) < norm(g,inf)
                    u = ut; acc = true; break;
                end
            end
            t = t/2;
        end
        if ~acc
            return;
        end
    end
    if ok
        H = Y1 - diag(p./u.^2);
        Hmin = min(eig(H));
    end
