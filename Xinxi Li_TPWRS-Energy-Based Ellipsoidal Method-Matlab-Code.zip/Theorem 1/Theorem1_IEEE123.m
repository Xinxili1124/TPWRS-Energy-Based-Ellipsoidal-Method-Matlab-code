clear; clc;

%% ===================== IEEE 123 network =====================
N = 123;
Y = zeros(N);
Y(1,36)=0.1;    Y(2,33)=1;      Y(3,39)=5;      Y(4,45)=0.2;    Y(5,47)=2;
Y(6,48)=0.5;    Y(7,50)=5;      Y(8,57)=1;      Y(9,58)=0.2;    Y(10,55)=4;
Y(11,73)=0.5;   Y(12,68)=4;     Y(13,69)=0.5;   Y(14,78)=4;     Y(15,79)=0.5;
Y(16,79)=10;    Y(17,82)=2;     Y(18,84)=1;     Y(19,103)=0.25; Y(20,91)=1;
Y(21,93)=2;     Y(22,112)=0.25; Y(23,113)=0.2;  Y(24,117)=5;    Y(25,118)=10;
Y(26,108)=0.2;  Y(27,122)=4;    Y(28,109)=0.5;  Y(29,112)=10;   Y(30,123)=5;
Y(31,34)=0.5;   Y(32,33)=4;     Y(32,35)=0.5;   Y(34,37)=10;    Y(35,38)=0.2;
Y(36,37)=2;     Y(37,38)=1;     Y(38,48)=0.25;  Y(39,40)=0.5;   Y(39,49)=0.2;
Y(40,41)=1;     Y(41,42)=0.2;   Y(42,43)=0.1;   Y(43,44)=4;     Y(44,51)=1;
Y(45,46)=4;     Y(45,52)=0.25;  Y(46,47)=1;     Y(48,57)=4;     Y(49,50)=2;
Y(49,53)=1;     Y(51,60)=2;     Y(51,52)=5;     Y(53,54)=4;     Y(53,58)=0.25;
Y(55,56)=0.5;   Y(56,59)=1;     Y(57,65)=10;    Y(58,67)=1;     Y(59,70)=0.1;
Y(60,61)=0.2;   Y(60,71)=0.5;   Y(61,62)=10;    Y(63,64)=2;     Y(64,65)=0.5;
Y(65,66)=0.2;   Y(65,94)=0.1;   Y(66,67)=5;     Y(67,68)=0.1;   Y(68,69)=1;
Y(70,84)=4;     Y(71,72)=1;     Y(71,74)=1;     Y(72,73)=10;    Y(74,75)=2;
Y(75,76)=0.5;   Y(75,86)=5;     Y(76,77)=5;     Y(77,78)=10;    Y(79,81)=4;
Y(80,91)=5;     Y(81,93)=0.25;  Y(82,83)=0.25;  Y(83,84)=0.2;   Y(83,98)=0.5;
Y(84,85)=2;     Y(85,86)=0.1;   Y(86,87)=0.5;   Y(86,101)=0.25; Y(87,88)=0.2;
Y(88,89)=1;     Y(89,90)=2;     Y(91,92)=10;    Y(91,109)=0.1;  Y(92,93)=1;
Y(93,94)=0.5;   Y(94,95)=1;     Y(94,104)=0.2;  Y(95,96)=0.2;   Y(96,97)=5;
Y(97,98)=2;     Y(98,99)=0.5;   Y(98,105)=4;    Y(99,100)=1;    Y(101,102)=5;
Y(101,106)=2;   Y(102,103)=10;  Y(104,112)=0.5; Y(105,114)=0.1; Y(106,107)=1;
Y(106,119)=0.1; Y(107,108)=10;  Y(108,120)=0.5; Y(109,110)=0.5; Y(110,111)=4;
Y(113,114)=2;   Y(114,116)=1;   Y(115,116)=0.5; Y(116,117)=0.2; Y(117,118)=1;
Y(118,119)=0.2; Y(120,121)=1;   Y(121,122)=0.25; Y(121,123)=0.2;
Y = diag((Y+Y')*ones(N,1))-Y-Y';

YSS = Y(1:30,1:30);
YSL = Y(1:30,31:123);
YLL = Y(31:123,31:123);
K = diag([0.5*ones(15,1); ones(15,1)]);
uref = 2846;
p = 1000*[5*ones(31,1);8*ones(31,1); 5*ones(31,1)];
n = numel(p);

delta = K\ones(30,1);
c = delta.'*(YSS\delta);
alphaRed = (delta.'*(YSS\YSL)).';
Y1 = YLL - YSL.'*(YSS\YSL) + (alphaRed*alphaRed.')/c;
Y1 = (Y1 + Y1.')/2;
xi = uref*sum(delta)*alphaRed/c;

%% Continuation of the two physical stationary-point branches
folder = fileparts(mfilename('fullpath'));
if isempty(folder), folder = pwd; end
baseLoad = p/uref^2;
loadScale = 1/norm(Y1\baseLoad,inf);
d = loadScale*baseLoad;
F = @(x,mu) Y1*x + xi/uref + mu*d./x;
H = @(x,mu) Y1 - diag(mu*d./x.^2);
fmu = @(x) d./x;
tol = 2e-13; arcStep = 0.01;
w = [-(Y1\(xi/uref));0];
tangent = [-Y1\fmu(w(1:n));1]; tangent=tangent/norm(tangent);
branch=nan(1600,2); states=nan(n+1,1600);
branch(1,:)=[0,min(eig(Y1))]; states(:,1)=w;
foldSeed=[];
for j=2:size(branch,1)
    pred=w+arcStep*tangent;
    w=correctPoint(pred,tangent.',F,H,fmu,tol);
    x=w(1:n);mu=w(end);Hx=H(x,mu);
    branch(j,:)=[mu*loadScale,min(eig(Hx))]; states(:,j)=w;
    nextTangent=[Hx,fmu(x);tangent.']\[zeros(n,1);1];
    nextTangent=nextTangent/norm(nextTangent);
    if isempty(foldSeed) && tangent(end)>0 && nextTangent(end)<0
        foldSeed=w;foldIndex=j;
    end
    tangent=nextTangent;
    if ~isempty(foldSeed) && branch(j,1)<foldSeed(end)*loadScale-0.20
        break;
    end
end
assert(~isempty(foldSeed),'No fold found. Increase continuation length.');
branch=branch(1:j,:);states=states(:,1:j);

%% Refine the saddle-node fold, then choose both points at ONE load factor
wf=foldSeed;[V,L]=eig(H(wf(1:n),wf(end)),'vector');
[~,ind]=min(L); z=V(:,ind);
for it=1:25
    xf=wf(1:n);mu=wf(end);Hf=H(xf,mu);
    residual=[F(xf,mu);Hf*z;(z.'*z-1)/2];
    if norm(residual,inf)<tol,break;end
    J=[Hf,fmu(xf),zeros(n); ...
        diag(2*mu*d.*z./xf.^3),-d.*z./xf.^2,Hf; ...
        zeros(1,n+1),z.'];
    change=J\residual;wf=wf-change(1:n+1);z=z-change(n+2:end);
end
assert(norm(residual,inf)<tol,'Fold refinement failed.');
lambdaFold=wf(end)*loadScale;uFold=uref*wf(1:n);

% Plot exactly at the ellipsoid-certificate limit
alphaPlot=1.9545;
foldGap=0.010;
if isempty(alphaPlot)
    alphaPlot=floor((lambdaFold-foldGap)*1000)/1000;
end
assert(alphaPlot>0 && alphaPlot<lambdaFold);
loadRow=[zeros(1,n),1]; muPlot=alphaPlot/loadScale;
upper=1:foldIndex-1;lower=foldIndex:size(branch,1);
[~,k1]=min(abs(branch(upper,1)-alphaPlot));
[~,k2]=min(abs(branch(lower,1)-alphaPlot));
wh=correctPoint([states(1:n,upper(k1));muPlot],loadRow,F,H,fmu,tol);
ws=correctPoint([states(1:n,lower(k2));muPlot],loadRow,F,H,fmu,tol);
uH=uref*wh(1:n);uSad=uref*ws(1:n);
HH=H(wh(1:n),muPlot);HS=H(ws(1:n),muPlot);
eigH=sort(eig(HH));[VS,eigSad]=eig(HS,'vector');
[eigSad,order]=sort(eigSad);VS=VS(:,order);
assert(eigH(1)>0 && eigSad(1)<0 && eigSad(2)>0, ...
    'Selected roots must be a strict local minimum and an index-one saddle.');
resH=norm(Y1*uH+xi+alphaPlot*p./uH,inf);
resSad=norm(Y1*uSad+xi+alphaPlot*p./uSad,inf);

% Retain the original finite multi-start check. This reports roots found;
% a finite numerical search is not a proof that no other roots exist.
runMultiStart=true;
maxPDH=NaN;
if runMultiStart
    maxPDH=0;
    for alphaTest=linspace(.02,lambdaFold-.02,40)
        found=[];
        for initialScale=[.1 .2 .35 .5 .7 .9 1]
            x=initialScale*ones(n,1);ok=false;
            for iteration=1:80
                g=Y1*x+xi/uref+alphaTest*baseLoad./x;
                if norm(g,inf)<1e-10,ok=true;break;end
                Jx=Y1-diag(alphaTest*baseLoad./x.^2);dx=-Jx\g;
                step=1;accepted=false;
                for lineSearch=1:40
                    xt=x+step*dx;
                    if all(xt>0) && norm(Y1*xt+xi/uref+alphaTest*baseLoad./xt,inf)<norm(g,inf)
                        x=xt;accepted=true;break;
                    end
                    step=step/2;
                end
                if ~accepted,break;end
            end
            if ok && min(eig(Y1-diag(alphaTest*baseLoad./x.^2)))>0
                if isempty(found) || min(vecnorm(found-x,2,1))>1e-4
                    found=[found,x]; %#ok<AGROW>
                end
            end
        end
        maxPDH=max(maxPDH,size(found,2));
    end
    fprintf('Maximum number of distinct PDH roots identified per loading factor: %d\n',maxPDH);
end

%% A two-dimensional voltage SECTION, not a projection of energy values
distance=norm(uSad-uH);q1=(uSad-uH)/distance;
% Orthogonalize the negative-curvature eigenvector. q2 itself is not
% generally an eigenvector; the resulting plane contains that eigenvector.
q2=VS(:,1)-q1*(q1.'*VS(:,1));
assert(norm(q2)>1e-9,'Section directions nearly coincide.');
q2=q2/norm(q2);
[~,imax]=max(abs(q2));if q2(imax)<0,q2=-q2;end
Q=[q1,q2];sectionEig=sort(eig(Q.'*HS*Q));
assert(sectionEig(1)<0 && sectionEig(2)>0);
energySad=energyChange(Y1,xi,alphaPlot*p,uH,uSad-uH);
assert(energySad>0);

% Fix the transverse width; all mesh points are checked for positive voltage.
transverseCurvature=max([q2.'*HH*q2,q2.'*HS*q2,eps]);
aHalf=0.15; % Fixed transverse width for this view
s=linspace(-0.20,1.20,181);
for attempt=1:20
    a=linspace(-aHalf,aHalf,121);[S,A]=meshgrid(s,a);
    du=distance*Q*[S(:).';A(:).'];
    if all(uH+du>0,'all'),break;end
    aHalf=0.8*aHalf;
end
assert(all(uH+du>0,'all'),'Section leaves the positive-voltage domain.');
E=reshape(energyChange(Y1,xi,alphaPlot*p,uH,du),size(S));

%% Energy surface: markers only, no guide lines
blue=[0.06 0.35 0.62];red=[0.72 0.25 0.14];
figEnergy=figure('Color','w','Position',[80 80 920 540]);
ax=axes(figEnergy,'Position',[0.13 0.15 0.82 0.78]);hold(ax,'on');
surf(ax,S,A,E,'EdgeColor','none','FaceAlpha',0.95,'FaceColor','interp');
colormap(ax,parula(256));
zMin=min(0,min(E(:)));zMax=100*ceil(max(400,1.05*max(E(:)))/100);
zRange=zMax-zMin;

% markers: smaller
plot3(ax,0,0,0,'o','MarkerSize',7,'MarkerFaceColor',blue, ...
    'MarkerEdgeColor','w','LineWidth',1.5);
plot3(ax,1,0,energySad,'d','MarkerSize',8,'MarkerFaceColor',red, ...
    'MarkerEdgeColor','w','LineWidth',1.5);

% labels: shifted left, right-aligned so coordinates can go on the right
text(ax,-0.12,0,0.17*zRange,'$u_{H}$', ...
    'Interpreter','latex','FontName','Times New Roman','Color',blue, ...
    'FontSize',26,'HorizontalAlignment','right','VerticalAlignment','bottom');
text(ax,0.88,0,energySad+0.17*zRange,'$u_{\mathrm{sad}}$', ...
    'Interpreter','latex','FontName','Times New Roman','Color',red, ...
    'FontSize',26,'HorizontalAlignment','right','VerticalAlignment','bottom');

xlabel(ax,'$s$','Interpreter','latex','FontName','Times New Roman','FontSize',26);
ylabel(ax,'$a$','Interpreter','latex','FontName','Times New Roman','FontSize',26);
zlabel(ax,'$\Delta E(u_{L})$','Interpreter','latex', ...
    'FontName','Times New Roman','FontSize',26);

view(ax,-48,27);camproj(ax,'orthographic');
pbaspect(ax,[1.35 1.0 .55]);
xlim(ax,[s(1)-0.06 s(end)+0.02]);ylim(ax,[-aHalf aHalf]);zlim(ax,[zMin zMax]);
xticks(ax,[0 .5 1]);yticks(ax,[-aHalf 0 aHalf]);
ytickformat(ax,'%.2f');
ax.ZAxis.Exponent=0;
zticks(ax,linspace(0,zMax,5));
set(ax,'FontName','Times New Roman','FontSize',24,'LineWidth',2.5, ...
    'SortMethod','childorder');
ax.XAxis.LineWidth=2.5;ax.YAxis.LineWidth=2.5;ax.ZAxis.LineWidth=2.5;
ax.XAxis.TickLength=[0.015 0.025];
ax.YAxis.TickLength=[0.015 0.025];
ax.ZAxis.TickLength=[0.015 0.025];
box(ax,'on');

%% Branch figure: axis limits follow the NEW fold, not the old case
figBranch=figure('Color','w','Position',[160 100 760 570]);
ab=axes(figBranch,'Position',[.15 .17 .80 .76]);hold(ab,'on');
high=[branch(1:foldIndex-1,:);lambdaFold,0];
low=[lambdaFold,0;branch(foldIndex:end,:)];
hp=plot(ab,high(:,1),1e3*high(:,2),'-','Color',blue,'LineWidth',1.8);
hs=plot(ab,low(:,1),1e3*low(:,2),'--','Color',red,'LineWidth',2.5);
plot(ab,alphaPlot,1e3*eigH(1),'o','Color',blue,'MarkerFaceColor',blue,'MarkerSize',7);
plot(ab,alphaPlot,1e3*eigSad(1),'d','Color',red,'MarkerFaceColor',red,'MarkerSize',8);
plot(ab,lambdaFold,0,'ko','MarkerFaceColor','w','MarkerSize',7);
xLeft=min(alphaPlot-0.02,lambdaFold-0.12);xRight=lambdaFold+.006;
xlim(ab,[xLeft xRight]);
visible=branch(:,1)>=xLeft;
yLo=1e3*min(branch(visible,2));yHi=1e3*max(branch(visible,2));
ylim(ab,[1.15*yLo 1.75*yHi]);
ab.YAxis.Exponent=0;
text(ab,0,1.025,'\times10^{-3}','Units','normalized', ...
    'Interpreter','tex','FontName','Times New Roman','FontSize',15, ...
    'VerticalAlignment','bottom','Clipping','off');
xlabel(ab,'Loading factor {\it\alpha}','Interpreter','tex');
ylabel(ab,'\lambda_{min}({\it H}({\it u}_{L}))','Interpreter','tex');
xticks(ab,[ceil(xLeft*100)/100,round((xLeft+lambdaFold)/2,2),round(lambdaFold,3)]);
xtickformat(ab,'%.3f');
text(ab,alphaPlot-.004,1e3*eigH(1)+.65*yHi, ...
    sprintf('{\\it u}_{H} (%.3f, %.3f)',alphaPlot,1e3*eigH(1)), ...
    'Interpreter','tex','Color',blue,'HorizontalAlignment','right','FontSize',14);
text(ab,alphaPlot-.004,1e3*eigSad(1)+.25*yHi, ...
    sprintf('{\\it u}_{sad} (%.3f, %.3f)',alphaPlot,1e3*eigSad(1)), ...
    'Interpreter','tex','Color',red,'HorizontalAlignment','right','FontSize',14);
text(ab,lambdaFold-.012,.20*yHi, ...
    sprintf('\\alpha_{fold} = %.5f',lambdaFold), ...
    'Interpreter','tex','HorizontalAlignment','right','FontSize',14);
legend(ab,[hp hs],{'Positive-definite Hessian branch','Saddle branch'}, ...
    'Location','northwest','FontSize',12,'Box','off');
set(ab,'FontName','Times New Roman','FontSize',16,'LineWidth',1.1);
grid(ab,'off');box(ab,'on');

%% Export all numerical evidence and native MATLAB figures
writematrix([uH,uSad],fullfile(folder,'uH_uSad_coordinates_V.csv'));
save(fullfile(folder,'theorem1_p342_results.mat'),'Y1','xi','p','uref', ...
    'lambdaFold','alphaPlot','uH','uSad','uFold','eigH','eigSad', ...
    'sectionEig','energySad','resH','resSad','maxPDH','S','A','E','Q', ...
    'distance','aHalf','high','low','branch');
exportgraphics(figEnergy,fullfile(folder,'theorem1_p342_flat_energy.png'),'Resolution',220);
exportgraphics(figEnergy,fullfile(folder,'theorem1_p342_flat_energy.pdf'),'ContentType','image','Resolution',300);
savefig(figEnergy,fullfile(folder,'theorem1_p342_flat_energy.fig'));
exportgraphics(figBranch,fullfile(folder,'theorem1_p342_flat_branches.png'),'Resolution',220);
exportgraphics(figBranch,fullfile(folder,'theorem1_p342_flat_branches.pdf'),'ContentType','vector');
savefig(figBranch,fullfile(folder,'theorem1_p342_flat_branches.fig'));
fprintf('\nalphaFold = %.12f; alphaPlot = %.3f\n',lambdaFold,alphaPlot);
fprintf('Energy saddle = %.9f; section a range = +/- %.8f\n',energySad,aHalf);
fprintf('min eig H(uH)=%.9g; min eig H(uSad)=%.9g\n',eigH(1),eigSad(1));
fprintf('PFE residuals in A: %.4e, %.4e\n',resH,resSad);
fprintf('Saddle section eigenvalues: %.9g, %.9g\n',sectionEig);
fprintf('Displayed energy range: %.8f to %.8f\n',min(E(:)),max(E(:)));

function w=correctPoint(pred,row,F,H,fmu,tol)
w=pred;
for k=1:24
    x=w(1:end-1);mu=w(end);
    assert(all(x>0),'Continuation left the positive-voltage domain.');
    residual=[F(x,mu);row*(w-pred)];
    if norm(residual,inf)<tol,return;end
    J=[H(x,mu),fmu(x);row];correction=J\residual;
    step=1;
    while any(w(1:end-1)-step*correction(1:end-1)<=0),step=step/2;end
    w=w-step*correction;
end
error('Continuation corrector did not converge.');
end

function dE=energyChange(Y1,xi,p,u,du)
r=du./u;
dE=.5*sum(du.*(Y1*du),1)+p.'*(log1p(r)-r) ...
    +(Y1*u+xi+p./u).'*du;
end
fprintf('\n--- Section coordinates of the two stationary points ---\n');
fprintf('u_H   : (s, a, dE) = (0, 0, 0)\n');
fprintf('u_sad : (s, a, dE) = (1, 0, %.9f)\n', energySad);
fprintf('s range = [%.2f, %.2f],  a range = [%+.3f, %+.3f]\n', ...
    s(1), s(end), -aHalf, aHalf);
fprintf('u_H   voltage: min = %.2f V, max = %.2f V\n', min(uH), max(uH));
fprintf('u_sad voltage: min = %.2f V, max = %.2f V\n', min(uSad), max(uSad));
fprintf('section directions: q1 = (u_sad-u_H)/|.|, q2 = orthogonalized unstable eigenvector\n');
%% ===================== 可编辑矢量图导出 =====================
drawnow;

energyEMF = fullfile(folder,'theorem1_p342_flat_energy.emf');
branchEMF = fullfile(folder,'theorem1_p342_flat_branches.emf');

% --- 3D 曲面：EMF 不支持透明，导出前临时改成不透明 ---
hSurf = findobj(ax,'Type','surface');
alphaBackup = get(hSurf,'FaceAlpha');
set(hSurf,'FaceAlpha',1);
drawnow;

print(figEnergy, energyEMF, '-dmeta','-painters');
print(figBranch, branchEMF, '-dmeta','-painters');

% --- 恢复透明，避免影响后续 PNG/PDF ---
set(hSurf,'FaceAlpha',alphaBackup);
drawnow;

% --- 保存可编辑图窗 ---
savefig(figEnergy, fullfile(folder,'theorem1_p342_flat_energy.fig'));
savefig(figBranch, fullfile(folder,'theorem1_p342_flat_branches.fig'));

fprintf('能量曲面 EMF：%s\n',energyEMF);
fprintf('分支曲线 EMF：%s\n',branchEMF);

% --- 复制到剪贴板（Visio 里“选择性粘贴 → 图元文件”） ---
try
    print(figEnergy,'-clipboard','-dmeta','-painters');
    fprintf('能量曲面已复制到剪贴板（EMF）。\n');
catch
    warning('剪贴板复制失败，请直接用上面的 EMF 文件。');
end