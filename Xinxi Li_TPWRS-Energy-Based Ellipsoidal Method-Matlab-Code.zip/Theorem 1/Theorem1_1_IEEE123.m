clear; clc;

%% IEEE 123-bus network with 30 sources and 93 loads
N = 123;
Y = zeros(N);
Y(1,36)=0.1;    Y(2,33)=1;      Y(3,39)=5;      Y(4,45)=0.2;    Y(5,47)=2;
Y(6,48)=0.5;    Y(7,50)=5;      Y(8,57)=1;      Y(9,58)=0.2;    Y(10,55)=4;
Y(11,73)=0.5;   Y(12,68)=4;     Y(13,69)=0.5;   Y(14,78)=4;     Y(15,79)=0.5;
Y(16,79)=10;    Y(17,82)=2;     Y(18,84)=1;     Y(19,103)=0.25; Y(20,91)=1;
Y(21,93)=2;     Y(22,112)=0.25; Y(23,113)=0.2;  Y(24,117)=5;    Y(25,118)=10;
Y(26,108)=0.2;  Y(27,122)=4;    Y(28,109)=0.5;  Y(29,112)=10;   Y(30,123)=5;
Y(31,34)=0.5;   Y(32,33)=4;     Y(32,35)=0.5;   Y(34,37)=10;    Y(35,38)=0.2;
Y(36,37)=2;     Y(37,38)=1;     Y(38,48)=0.25;  Y(39,40)=0.5;   Y(39,49)=0.2;
Y(40,41)=1;     Y(41,42)=0.2;   Y(42,43)=0.1;   Y(43,44)=4;     Y(44,51)=1;
Y(45,46)=4;     Y(45,52)=0.25;  Y(46,47)=1;     Y(48,57)=4;     Y(49,50)=2;
Y(49,53)=1;     Y(51,60)=2;     Y(51,52)=5;     Y(53,54)=4;     Y(53,58)=0.25;
Y(55,56)=0.5;   Y(56,59)=1;     Y(57,65)=10;    Y(58,67)=1;     Y(59,70)=0.1;
Y(60,61)=0.2;   Y(60,71)=0.5;   Y(61,62)=10;    Y(63,64)=2;     Y(64,65)=0.5;
Y(65,66)=0.2;   Y(65,94)=0.1;   Y(66,67)=5;     Y(67,68)=0.1;   Y(68,69)=1;
Y(70,84)=4;     Y(71,72)=1;     Y(71,74)=1;     Y(72,73)=10;    Y(74,75)=2;
Y(75,76)=0.5;   Y(75,86)=5;     Y(76,77)=5;     Y(77,78)=10;    Y(79,81)=4;
Y(80,91)=5;     Y(81,93)=0.25;  Y(82,83)=0.25;  Y(83,84)=0.2;   Y(83,98)=0.5;
Y(84,85)=2;     Y(85,86)=0.1;   Y(86,87)=0.5;   Y(86,101)=0.25; Y(87,88)=0.2;
Y(88,89)=1;     Y(89,90)=2;     Y(91,92)=10;    Y(91,109)=0.1;  Y(92,93)=1;
Y(93,94)=0.5;   Y(94,95)=1;     Y(94,104)=0.2;  Y(95,96)=0.2;   Y(96,97)=5;
Y(97,98)=2;     Y(98,99)=0.5;   Y(98,105)=4;    Y(99,100)=1;    Y(101,102)=5;
Y(101,106)=2;   Y(102,103)=10;  Y(104,112)=0.5; Y(105,114)=0.1; Y(106,107)=1;
Y(106,119)=0.1; Y(107,108)=10;  Y(108,120)=0.5; Y(109,110)=0.5; Y(110,111)=4;
Y(113,114)=2;   Y(114,116)=1;   Y(115,116)=0.5; Y(116,117)=0.2; Y(117,118)=1;
Y(118,119)=0.2; Y(120,121)=1;   Y(121,122)=0.25; Y(121,123)=0.2;
Y = diag((Y+Y')*ones(N,1))-Y-Y';

YSS = Y(1:30,1:30);
YSL = Y(1:30,31:123);
YLL = Y(31:123,31:123);
K = diag([0.5*ones(15,1); ones(15,1)]);
uref = 2846;
p = 1000*1.9545*[5*ones(31,1); 8*ones(31,1); 5*ones(31,1)];
n = numel(p);

delta = K\ones(30,1);
c = delta.'*(YSS\delta);
alphaRed = (delta.'*(YSS\YSL)).';
Y1 = YLL - YSL.'*(YSS\YSL) + (alphaRed*alphaRed.')/c;
Y1 = (Y1 + Y1.')/2;
xi = uref*sum(delta)*alphaRed/c;

gradient = @(u) Y1*u + xi + p./u;
hessian  = @(u) Y1 - diag(p./u.^2);

%% New fixed-point candidate (ellipsoid center)
B = Y1\diag(p)/uref^2;
eta = B*ones(n,1);
if any(1-4*eta <= 0)
    error('New candidate undefined: need 4*max(eta) < 1.');
end
z = (1+sqrt(1-4*eta))/2;
v0 = uref*(1 - B*(1./z));

[~,H0,lhs,rhs,h,beta,kappa,R,flag] = certificate(v0,gradient,hessian,p);

if flag ~= 0
    error('H(v0) is not positive definite (flag=%d).',flag);
end

Fval = lhs + 2*sqrt(kappa*lhs);
fprintf('\n--- New-candidate certificate ---\n');
fprintf('max eta = %.9f\n',max(eta));
fprintf('h      = %.9e\n',h);
fprintf('beta   = %.9e\n',beta);
fprintf('kappa  = %.9f\n',kappa);
fprintf('h*beta = %.9f\n',lhs);
fprintf('RHS    = %.9f\n',rhs);
fprintf('F = h*beta + 2*sqrt(kappa*h*beta) = %.9f  (%s)\n', ...
    Fval,pf(Fval<1,'PASS','FAIL'));
if ~(lhs < rhs)
    error('Theorem 2 does not certify the new candidate.');
end

%% Choose rho = h*r so the ellipsoid is admissible
rhoOpt = 1 - sqrt(kappa/(1+kappa));
rho = rhoOpt/2;
disc = (1+lhs)^2 - 4*(1+kappa)*lhs;
if rho - kappa*rho^2/(1-rho) <= lhs
    if disc > 0
        rhoLower = 2*lhs/(1+lhs+sqrt(disc));
        rho = (rhoLower + rhoOpt)/2;
    else
        error('No admissible rho.');
    end
end
r = rho/h;
radialMargin = 1 - beta/r - kappa*rho/(1-rho);
curvature    = 1 - kappa*((1-rho)^(-2)-1);
fprintf('rho = h*r = %.9f,  r = %.9f V\n',rho,r);
fprintf('radial margin = %.9f, curvature bound = %.9f\n',radialMargin,curvature);
if ~(rho>0 && rho<1 && radialMargin>0 && curvature>0)
    error('Ellipsoid parameters are not admissible.');
end

%% Locate the actual power-flow solution inside the ellipsoid
uStar = v0;
tol = 1e-8;
for k = 1:40
    gk = gradient(uStar);
    if norm(gk,inf) < tol, break; end
    step = hessian(uStar)\gk;
    t = 1;
    while any(uStar - t*step <= 0) && t > 1e-6
        t = t/2;
    end
    uStar = uStar - t*step;
end
residual = norm(gradient(uStar),inf);
minEig = min(eig(hessian(uStar)));
etaStar = R*(uStar-v0);
relativeDistance = norm(etaStar)/r;

fprintf('\n--- Numerical checks ---\n');
fprintf('current-balance residual : %.3e A\n',residual);
fprintf('relative ellipsoid dist  : %.9f\n',relativeDistance);
fprintf('smallest eig of H(uStar) : %.9g\n',minEig);

if ~(all(uStar>0) && residual<tol && relativeDistance<1 && minEig>0)
    warning('Some checks are not satisfied.');
end

%% Section: u(s,a) = v0 + r*R^{-1}*(q1*s + q2*a)
q1 = etaStar/norm(etaStar);
[~,i] = min(abs(q1));
e = zeros(n,1); e(i) = 1;
q2 = e - q1*(q1.'*e);
q2 = q2/norm(q2);
section = r*(R\[q1,q2]);

energy = @(du) 0.5*sum(du.*(Y1*du),1) ...
    + p.'*(log1p(du./uStar)-du./uStar) + gradient(uStar).'*du;

[S,T] = meshgrid(linspace(-1,1,281));
in = S.^2+T.^2 <= 1;
E = nan(size(S));
U = v0 + section*[S(in).'; T(in).'];
E(in) = energy(U-uStar);
Emax = max(E(in));

s = sort([linspace(-1,1,501), 0, relativeDistance]);
Eline = energy(v0 + section(:,1)*s - uStar);
centerEnergy = energy(v0-uStar);

%% Contour figure
blue = [0.06 0.31 0.56];
red  = [0.72 0.25 0.14];
ink  = [0.16 0.20 0.23];

figContour = figure('Color','w','Position',[90 90 620 500]);
ax1 = axes(figContour,'Position',[0.12 0.15 0.76 0.76]);
hold(ax1,'on');

levels = linspace(0,1.05*Emax,14);
contourf(ax1,S,T,E,levels,'LineColor','none');
contour(ax1,S,T,E,levels(2:end-1),'LineColor',[0.30 0.40 0.45],'LineWidth',1);
colormap(ax1,flipud(parula(128)));
clim(ax1,[0,Emax]);

cb = colorbar(ax1,'eastoutside');
cb.Label.Interpreter = 'latex';
cb.Label.String = '$\Delta\mathcal{E}$';
cb.FontSize = 20;
cb.Label.FontSize = 20;
cb.Ruler.Exponent = 0;
cb.Ruler.ExponentMode = 'manual';
cb.Ruler.Exponent = 3;
cb.Label.String = '$\Delta\mathcal{E}$';
a = linspace(0,2*pi,400);
plot(ax1,cos(a),sin(a),'-','Color',ink,'LineWidth',2);
plot(ax1,0,0,'o','Color',blue,'MarkerFaceColor',blue,'MarkerSize',11);
plot(ax1,relativeDistance,0,'o','Color',red,'MarkerFaceColor',red,'MarkerSize',11);

yLabel = 0.10;
text(ax1,-0.06,yLabel,'$v_{*}\ (0,0)$','Color',blue, ...
    'HorizontalAlignment','right','VerticalAlignment','middle', ...
    'Interpreter','latex','FontSize',21);
text(ax1,relativeDistance-0.03,0.08, ...
    sprintf('$u_L^*\\ (%.3f,0)$',relativeDistance),'Color',red, ...
    'HorizontalAlignment','center','VerticalAlignment','bottom', ...
    'Interpreter','latex','FontSize',21);

axis(ax1,'equal');
xlim(ax1,[-1.08 1.12]); ylim(ax1,[-1.06 1.06]);
xticks(ax1,-1:0.5:1); yticks(ax1,-1:0.5:1);
xlabel(ax1,'$s$','Interpreter','latex');
ylabel(ax1,'$a$','Interpreter','latex');
box(ax1,'on');

%% Profile figure
figProfile = figure('Color','w','Position',[130 130 650 500]);
ax2 = axes(figProfile,'Position',[0.15 0.15 0.80 0.76]);
hold(ax2,'on');

plot(ax2,s,Eline,'-','Color',ink,'LineWidth',2);
xline(ax2,-1,':','Color',[0.46 0.48 0.50]);
xline(ax2, 1,':','Color',[0.46 0.48 0.50]);
plot(ax2,0,centerEnergy,'o','Color',blue,'MarkerFaceColor',blue,'MarkerSize',9);
plot(ax2,relativeDistance,0,'o','Color',red,'MarkerFaceColor',red,'MarkerSize',9);

text(ax2,0,centerEnergy+0.045*max(Eline),'$v_{*}$','Interpreter','latex', ...
    'Color',blue,'HorizontalAlignment','center','FontSize',21);
text(ax2,relativeDistance,0.09*max(Eline),'$u_L^*$', ...
    'Interpreter','latex','Color',red,'HorizontalAlignment','center','FontSize',21);

xlim(ax2,[-1.07 1.07]);
ylim(ax2,[-0.035 1.08]*max(Eline));
ax2.YAxis.Exponent = 3;
xticks(ax2,-1:0.5:1);
xlabel(ax2,'$s$ along $a=0$','Interpreter','latex');
ylabel(ax2,'$\Delta\mathcal{E}$','Interpreter','latex');
box(ax2,'on');

set([ax1,ax2],'FontName','Times New Roman','FontSize',18,'LineWidth',2);
ax1.Toolbar.Visible = 'off';
ax2.Toolbar.Visible = 'off';

%% Export
folder = fileparts(mfilename('fullpath'));
if isempty(folder), folder = pwd; end
drawnow;

exportgraphics(figContour,fullfile(folder,'theorem2_fixed_contours.png'),'Resolution',300);
exportgraphics(figContour,fullfile(folder,'theorem2_fixed_contours.pdf'), ...
    'ContentType','image','Resolution',400);
exportgraphics(figProfile,fullfile(folder,'theorem2_fixed_profile.png'),'Resolution',300);
exportgraphics(figProfile,fullfile(folder,'theorem2_fixed_profile.pdf'), ...
    'ContentType','image','Resolution',400);
savefig(figContour,fullfile(folder,'theorem2_fixed_contours.fig'));
savefig(figProfile,fullfile(folder,'theorem2_fixed_profile.fig'));

fprintf('\nalpha = 1.95, load blocks = [%.3f, %.3f, %.3f] kW\n', ...
    p(1)/1000,p(32)/1000,p(63)/1000);

%% Local functions
function [g,H,lhs,rhs,h,beta,kappa,R,flag] = certificate(v,gradient,hessian,p)
    g = gradient(v);
    H = hessian(v);
    lhs = NaN; rhs = NaN; h = NaN; beta = NaN; kappa = NaN; R = [];
    if any(v <= 0)
        flag = 2; return;
    end
    [R,flag] = chol(H);
    if flag ~= 0
        return;
    end
    inverseR = R\eye(numel(v));
    h     = max(vecnorm(inverseR,2,2)./v);
    beta  = norm(R.'\g);
    kappa = norm(R\(R.'\diag(p./v.^2)),inf);
    lhs   = h*beta;
    rhs   = (sqrt(1+kappa)-sqrt(kappa))^2;
end

function out = pf(cond,a,b)
    if cond
        out = a;
    else
        out = b;
    end
end